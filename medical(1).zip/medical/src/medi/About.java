package medi;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Exception;
import java.io.*;

import javax.swing.*;


class InvalidExcepti extends Exception
{
}

class About extends JFrame implements ActionListener {
    
    
    
    
    
    
    JFrame jf1;
    Font f;
    int cnt=0,cnt1=0;
    JLabel ques3,ques2,ques,ques1,fg;
    
    
   
    JButton next;
    
    About()
    {
        jf1=new JFrame();
        f = new Font("Times New Roman",Font.BOLD,20);
        jf1.getContentPane().setLayout(null);
        

        fg = new JLabel("WELCOME TO GET WELL MEDICAL STORE");
        fg.setForeground(Color.BLACK);fg.setFont(new Font("Times New Roman", Font.BOLD, 35));
        fg.setBounds(19,116,800,80);
        jf1.getContentPane().add(fg);

        ques1 = new JLabel("Suteja Patil (TC151)");
        ques1.setForeground(Color.BLACK);
        ques1.setFont(new Font("Tahoma", Font.BOLD, 15));
        ques1.setBounds(440, 355, 350, 19);
        jf1.getContentPane().add(ques1);

        ques2 = new JLabel("Sukrut Pendharkar (TC152)");
        ques2.setForeground(Color.BLACK);
        ques2.setFont(new Font("Tahoma", Font.BOLD, 15));
        ques2.setBounds(440, 385, 350, 19);
        jf1.getContentPane().add(ques2);

        ques3 = new JLabel("Mihir Phatak (TC153)");
        ques3.setForeground(Color.BLACK);
        ques3.setFont(new Font("Tahoma", Font.BOLD, 15));
        ques3.setBounds(440, 415, 350, 19);
        jf1.getContentPane().add(ques3);
        
        
        
       
        
        ques = new JLabel("Project by:  Shreeya Tahasildar (TC167)");
        ques.setForeground(Color.BLACK);
        ques.setFont(new Font("Tahoma", Font.BOLD, 15));
        ques.setBounds(342, 325, 350, 19);
        jf1.getContentPane().add(ques);
        
       
        
     
        
        
        next = new JButton("NEXT");
        next.setFont(new Font("Tahoma", Font.BOLD, 15));
        next.setBounds(198, 454, 104, 33);
        jf1.getContentPane().add(next);next.addActionListener(this);
        
       
        
        

        jf1.setTitle("About");
        jf1.setLocation(20,20);
        jf1.setSize(800,600);
        jf1.setResizable(false);
        jf1.getContentPane().setBackground(Color.WHITE);
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/med.jpg"));
        lblNewLabel.setBounds(0, 0, 786, 563);
        jf1.getContentPane().add(lblNewLabel);
        jf1.setVisible(true);
        
        
        
    }

    
    
    
    
    
    


    
    public void actionPerformed(ActionEvent ac) {
        
        

        

        if(ac.getSource()==next)
        {
            new Login();
            jf1.setVisible(false);

        }

    }

    public static void main(String args[])
    {
        new About();

    }
        
}