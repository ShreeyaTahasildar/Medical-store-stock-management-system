package medi;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.ResultSet;

public class SearchSupplier extends JFrame implements ActionListener
{
	JFrame jf;
	JTextField t1,t2,t3,t4,t5;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
    Connection con;
	PreparedStatement ps;
	Statement stmt;
	ResultSet rs;
	DefaultTableModel model = new DefaultTableModel();
	private JLabel lblNewLabel;

	SearchSupplier()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.getContentPane().setLayout(null);

	    l6=new JLabel("Search Supplier");
	    l6.setFont(new Font("Times New Roman", Font.BOLD, 25));
	    l6.setBounds(179,29,300,40);l6.setForeground(Color.WHITE);
	    jf.getContentPane().add(l6);

		l1= new JLabel("Search by id *");
		l1.setFont(new Font("Tahoma", Font.BOLD, 15));
		l1.setForeground(Color.WHITE);
		
   l1.setBounds(61,97,130,25);
		jf.getContentPane().add(l1);

		t1=new JTextField(20);
		t1.setBounds(232,99,100,25);t1.setToolTipText("Enter supplier id to search supplier");
		jf.getContentPane().add(t1);

		l2 = new JLabel("Search by name *");
		l2.setFont(new Font("Tahoma", Font.BOLD, 15));
		l2.setForeground(Color.WHITE);
		
   l2.setBounds(61,132,170,25);
		jf.getContentPane().add(l2);

		t2=new JTextField(20);
		t2.setBounds(229,134,200,25);t2.setToolTipText("Enter supplier name to search supplier");
		jf.getContentPane().add(t2);

		l3 = new JLabel("Supplier address");
		l3.setFont(new Font("Tahoma", Font.BOLD, 15));
		l3.setForeground(Color.WHITE);
		
   l3.setBounds(61,167,170,25);
		jf.getContentPane().add(l3);

		t3=new JTextField(20);
		t3.setBounds(229,169,250,25);jf.getContentPane().add(t3);

		l4 = new JLabel("Supplier phone no");
		l4.setFont(new Font("Tahoma", Font.BOLD, 15));
		l4.setForeground(Color.WHITE);
		
   l4.setBounds(61,202,170,25);
		jf.getContentPane().add(l4);

		t4=new JTextField(20);
		t4.setBounds(229,204,100,25);jf.getContentPane().add(t4);

		l5 = new JLabel("Supplier email id");
		l5.setFont(new Font("Tahoma", Font.BOLD, 15));
		l5.setForeground(Color.WHITE);
		
   l5.setBounds(61,237,170,25);
		jf.getContentPane().add(l5);

		t5=new JTextField(20);
		t5.setBounds(229,239,200,25);jf.getContentPane().add(t5);


        b0 = new JButton("Search");
        b0.setFont(new Font("Tahoma", Font.BOLD, 15));
        b0.setBounds(50,301,110,35);b0.setToolTipText("click to open supplier details");
		jf.getContentPane().add(b0);b0.addActionListener(this);

		b1 = new JButton("Reset");
		b1.setFont(new Font("Tahoma", Font.BOLD, 15));
		b1.setBounds(208,301,110,35);b1.setToolTipText("click to clear all textfields");
	    jf.getContentPane().add(b1); b1.addActionListener(this);

        b2= new JButton("Back");
        b2.setFont(new Font("Tahoma", Font.BOLD, 15));
		b2.setBounds(369,301,110,35);b2.setToolTipText("click to go to main menu");
		jf.getContentPane().add(b2); b2.addActionListener(this);

      model.addColumn("S_ID");
      model.addColumn("S_NAME");
      model.addColumn("S_ADDRESS");
      model.addColumn("S_PHONENO");
      model.addColumn("S_EMAILID");

	     jf.setTitle("Search Supplier");
	     jf.setSize(900,700);
		 jf.setLocation(20,20);
		 jf.setResizable(false);
		 jf.getContentPane().setBackground(Color.WHITE);
		 
		 lblNewLabel = new JLabel("New label");
		 lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		 lblNewLabel.setForeground(Color.BLACK);
		 lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/Suppliers.jpg"));
		 lblNewLabel.setBounds(0, 0, 897, 675);
		 jf.getContentPane().add(lblNewLabel);
	     jf.setVisible(true);

	}
 public void actionPerformed(ActionEvent ae)
    {
    if(ae.getSource()==b0)
	 {//fetch
	  try
	   {
	   		if(((t1.getText()).equals(""))&&((t2.getText()).equals("")))
	        {
		    JOptionPane.showMessageDialog(this,"Please enter supplier id or name !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
	        else
	        {
	         int foundrec = 0;
	    Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store","root","rootpasswordgiven");
		System.out.println("Connected to database.");
         ps=con.prepareStatement("select * from supplier where sid='"+t1.getText()+"' or sname='"+t2.getText()+"'");
	      rs=ps.executeQuery();
		  while(rs.next())
	      {
		    t1.setText(rs.getString(1));
	        t2.setText(rs.getString(2));
	        t3.setText(rs.getString(3));
	        t4.setText(rs.getString(4));
		    t5.setText(rs.getString(5));
		     foundrec = 1;
	       }
	       if (foundrec == 0)
                {
                    JOptionPane.showMessageDialog(null,"Record is not available","Dialog",JOptionPane.WARNING_MESSAGE);
                }
	      }
	       con.close();
        }
        catch(SQLException se)
		{
		System.out.println(se);
	     JOptionPane.showMessageDialog(null,"SQL Error:"+se);
        }
	    catch(Exception e)
	     {
	     System.out.println(e);
		 JOptionPane.showMessageDialog(null,"Error:"+e);
	     }
    }
     else if(ae.getSource()==b1)
      {//clear
          t1.setText("");
          t2.setText("");
          t3.setText("");
          t4.setText("");
          t5.setText("");

      }
    else if(ae.getSource()==b2)
    {
    	new MainMenu();
    	jf.setVisible(false);
	}
   }

	public static void main(String args[])
	{
	    new SearchSupplier();
	}
}

