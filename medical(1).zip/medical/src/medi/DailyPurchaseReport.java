package medi;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.ResultSet;

public class DailyPurchaseReport extends JFrame implements ActionListener
 {
    JFrame jf;
    JButton submit,print,btnBack;
    JLabel l1,ln;
    JTextField t1;
    Font f;
    Connection con;
    PreparedStatement ps;
    Statement stmt;
    ResultSet rs;
     DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

  public DailyPurchaseReport()
  {
   jf=new JFrame();
   f = new Font("Times New Roman",Font.BOLD,20);
   jf.getContentPane().setLayout(null);

      ln = new JLabel("Daily purchase report");
    ln.setFont(new Font("Times New Roman", Font.BOLD, 30));
    ln.setForeground(Color.BLACK);
    ln.setBounds(256,25,300,25);
    jf.getContentPane().add(ln);

    l1 = new JLabel("Enter purchase report date:");
    l1.setFont(new Font("Tahoma", Font.BOLD, 15));
  
  l1.setBounds(131,100,250,25);
    jf.getContentPane().add(l1);

    t1=new JTextField(10);
    t1.setBounds(360,100,133,25);t1.setToolTipText("Enter purchase report date");
    jf.getContentPane().add(t1);

    submit = new JButton("Submit");
    submit.setFont(new Font("Tahoma", Font.BOLD, 15));
    submit.setForeground(new Color(0, 0, 0));
    submit.setBounds(120,150,110,35); submit.setToolTipText("click to open daily purchase report");
    jf.getContentPane().add(submit);submit.addActionListener(this);

    print = new JButton("Print");
    print.setFont(new Font("Tahoma", Font.BOLD, 15));
    print.setForeground(new Color(0, 0, 0));
    print.setBounds(300,150,110,35);print.setToolTipText("click to print");
    jf.getContentPane().add(print);print.addActionListener(this);

    scrlPane.setBounds(0,200,900,600);
    jf.getContentPane().add(scrlPane);
    tabGrid.setFont(new Font ("Times New Roman",0,15));

       model.addColumn("SuppierID");
       model.addColumn("SupplierName");
      model.addColumn("MedBno");
      model.addColumn("MedName");
      model.addColumn("MedExpDate");
      model.addColumn("MedQty");
      model.addColumn("MedPurPrice");
      

    jf.setTitle("Daily Purchase Report");
    jf.setSize(900,700);
    jf.setLocation(20,20);
    jf.setResizable(false);
    jf.getContentPane().setBackground(Color.pink);
    
    btnBack=new JButton("Back");
    btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
    btnBack.setForeground(new Color(0, 0, 0));
    btnBack.setBounds(471, 150, 97, 35);
    jf.getContentPane().add(btnBack);
    btnBack.addActionListener(this);
    
    JLabel lblNewLabel = new JLabel("New label");
    lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/DeleteMedicine.jpg"));
    lblNewLabel.setBounds(0, 0, 886, 201);
    jf.getContentPane().add(lblNewLabel);
    jf.setVisible(true);
  }

      public void actionPerformed(ActionEvent ae)
    {
    if(ae.getSource()==submit)
     {
      int r = 0;
     try
     {
             if(((t1.getText()).equals("")))
            {
            JOptionPane.showMessageDialog(this,"Please enter purchase date !","Warning!!!",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
             int foundrec = 0;
         Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store","root","rootpasswordgiven");
        System.out.println("Connected to database.");
        stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rs = stmt.executeQuery("SELECT sid,sname,mbno,mname,mexpdate,mqty,mpurprice from medicine where mpurdate='"+t1.getText()+"' order by sid asc");
          while(rs.next())
            {
                model.insertRow(r++,new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)});
              foundrec = 1;
            }
              if (foundrec == 0)
                {
                    JOptionPane.showMessageDialog(null,"Not any medicine purchase on given date","Dialog",JOptionPane.WARNING_MESSAGE);
                }
            }
             con.close();
       }
      catch(SQLException se)
       {
             System.out.println(se);
          JOptionPane.showMessageDialog(null,"SQL Error:"+se);
       }
       catch(Exception e)
       {
              System.out.println(e);
           JOptionPane.showMessageDialog(null,"Error:"+e);
       }
    }

     else if(ae.getSource()==print)
     {
         
     }
    
     else if(ae.getSource()==btnBack)
     {
    	 new MainMenu();
    	 jf.setVisible(false);
     }
    }

  public static void main(String args[])
    {
        new DailyPurchaseReport();
    }
}