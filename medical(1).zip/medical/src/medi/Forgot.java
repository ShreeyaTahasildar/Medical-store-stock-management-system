package medi;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Exception;
import java.io.*;

import javax.swing.*;


class InvalidExceptio extends Exception
{
}

class Forgot extends JFrame implements ActionListener {
    
    
    
    
    
    
    JFrame jf1;
    Font f;
    int cnt=0,cnt1=0;
    JLabel sq,eu,ques,ans,fg;
    
    
    JTextField textField,t1;
    JButton sub,bck;
    
    Forgot()
    {
        jf1=new JFrame();
        f = new Font("Times New Roman",Font.BOLD,20);
        jf1.getContentPane().setLayout(null);
        

        fg = new JLabel("Forgot Password");
        fg.setForeground(Color.BLACK);fg.setFont(new Font("Times New Roman", Font.BOLD, 30));
        fg.setBounds(219,116,300,80);
        jf1.getContentPane().add(fg);

        

        eu = new JLabel("Enter User Name : "); 
        eu.setForeground(Color.BLACK);eu.setFont(new Font("Tahoma", Font.BOLD, 15));
        eu.setBounds(154,250,186,25);
        jf1.getContentPane().add(eu);

        t1 = new JTextField(20);
        t1.setBounds(350,250,200,25);
        t1.setToolTipText("Enter Username");
        jf1.getContentPane().add(t1);
        
        
        
        sq = new JLabel("Security Question :");
        sq.setFont(new Font("Tahoma", Font.BOLD, 15));
        sq.setForeground(Color.BLACK);
        sq.setBounds(150, 312, 176, 44);
        jf1.getContentPane().add(sq);
        
        ques = new JLabel("You started your shop on?");
        ques.setForeground(Color.BLACK);
        ques.setFont(new Font("Tahoma", Font.BOLD, 15));
        ques.setBounds(342, 325, 250, 19);
        jf1.getContentPane().add(ques);
        
        ans = new JLabel("Answer :");
        ans.setForeground(Color.BLACK);
        ans.setFont(new Font("Tahoma", Font.BOLD, 15));
        ans.setBounds(236, 386, 118, 25);
        jf1.getContentPane().add(ans);
        
        textField = new JTextField();
        textField.setBounds(350, 386, 143, 25);
        textField.setToolTipText("Enter Date in DD/MM/YYYY");
        jf1.getContentPane().add(textField);
        
        
        sub = new JButton("Submit");
        sub.setFont(new Font("Tahoma", Font.BOLD, 15));
        sub.setBounds(198, 454, 104, 33);
        jf1.getContentPane().add(sub);sub.addActionListener(this);
        
        bck = new JButton("Back");
        bck.setFont(new Font("Tahoma", Font.BOLD, 15));
        bck.setBounds(447, 454, 103, 33);
        jf1.getContentPane().add(bck);bck.addActionListener(this);
        
        

        jf1.setTitle("Forgot Password");
        jf1.setLocation(20,20);
        jf1.setSize(800,600);
        jf1.setResizable(false);
        jf1.getContentPane().setBackground(Color.WHITE);
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/wp2013740.jpg"));
        lblNewLabel.setBounds(0, 0, 786, 563);
        jf1.getContentPane().add(lblNewLabel);
        jf1.setVisible(true);
        
        
        
    }

    
    
    
    
    
    


    
    public void actionPerformed(ActionEvent ac) {
        
        if(ac.getSource()==sub)
        {
            try {
            
                String s3=t1.getText();
                String s4=textField.getText();
                if((s3.compareTo("admin")==0)&&(s4.compareTo("15/06/2006")==0))
                {
                    JOptionPane.showMessageDialog(null," Welcome !!! You are valid user ...!!! Your Password is: admin123  ",null,JOptionPane.INFORMATION_MESSAGE);
                       jf1.setVisible(false);
                       new Login();
                }
        
                else
                {
                    throw new InvalidException();
                }
            }
                catch(Exception e2)
            {
            
            
                cnt++;
                JOptionPane.showMessageDialog(null," Sorry !!! You are not a valid user ...!!!","WARNING",JOptionPane.ERROR_MESSAGE);
                t1.setText("");
                textField.setText("");
                if(cnt==2)
                {
                     JOptionPane.showMessageDialog(null,"Sorry !!! Your 2 attempts are over ...!!!",null,JOptionPane.ERROR_MESSAGE);
                     System.exit(0);
                }
            }
        }
            

        

        else if(ac.getSource()==bck)
        {
            new Login();
            jf1.setVisible(false);

        }

    }

    public static void main(String args[])
    {
        new Forgot();

    }
        
}