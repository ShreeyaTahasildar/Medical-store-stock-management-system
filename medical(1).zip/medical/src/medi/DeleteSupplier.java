package medi;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.ResultSet;


public class DeleteSupplier extends JFrame implements ActionListener
{
	JFrame jf;
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField t1,t2,t3,t4,t5;
	JButton b0,b1,b2,b3;
	GridBagLayout gbl;
	GridBagConstraints gbc;
	Font f;
    Connection con;
	PreparedStatement ps;
	Statement stmt;
	ResultSet rs;
    DefaultTableModel model = new DefaultTableModel();
    private JLabel lblNewLabel;

	DeleteSupplier()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.getContentPane().setLayout(null);

	    l6=new JLabel(" Delete Supplier ");
	    l6.setFont(new Font("Times New Roman", Font.BOLD, 30));
	    l6.setBounds(193,44,300,40);l6.setForeground(Color.BLACK);
	    jf.getContentPane().add(l6);

		l1= new JLabel("Supplier id*");
		l1.setForeground(Color.BLACK);
		l1.setFont(new Font("Tahoma", Font.BOLD, 15));
		//l1.setFont(f);
 l1.setBounds(101,107,140,25);
		jf.getContentPane().add(l1);

		t1=new JTextField(20);
		t1.setBounds(276,109,100,25);t1.setToolTipText("Enter supplier id to delete supplier");
		jf.getContentPane().add(t1);

		l2 = new JLabel("Supplier name*");
		l2.setForeground(Color.BLACK);
		l2.setFont(new Font("Tahoma", Font.BOLD, 15));
		//l2.setFont(f);
  l2.setBounds(99,142,180,25);
		jf.getContentPane().add(l2);

		t2=new JTextField(20);
		t2.setBounds(276,144,200,25);t2.setToolTipText("Enter supplier name to delete supplier");
		jf.getContentPane().add(t2);

		l3 = new JLabel("Supplier address");
		l3.setForeground(Color.BLACK);
		l3.setFont(new Font("Tahoma", Font.BOLD, 15));
		//l3.setFont(f);
    l3.setBounds(101,177,180,25);
		jf.getContentPane().add(l3);

		t3=new JTextField(20);
		t3.setBounds(274,179,250,25);jf.getContentPane().add(t3);

		l4 = new JLabel("Supplier phone no");
		l4.setForeground(Color.BLACK);
		l4.setFont(new Font("Tahoma", Font.BOLD, 15));
		//l4.setFont(f);
   l4.setBounds(99,212,180,25);
		jf.getContentPane().add(l4);

		t4=new JTextField(20);
		t4.setBounds(276,214,100,25);jf.getContentPane().add(t4);

		l5 = new JLabel("Supplier email id");
		l5.setForeground(Color.BLACK);
		l5.setFont(new Font("Tahoma", Font.BOLD, 15));
		//l5.setFont(f);
   l5.setBounds(99,247,180,25);
		jf.getContentPane().add(l5);

		t5=new JTextField(20);
		t5.setBounds(276,249,200,25);jf.getContentPane().add(t5);

		 b0 = new JButton("Open");
		 b0.setFont(new Font("Tahoma", Font.BOLD, 15));
		 b0.setBackground(Color.WHITE);
		 b0.setBounds(48,337,100,35);b0.setToolTipText("click to open supplier details");
	     jf.getContentPane().add(b0); b0.addActionListener(this);

	     b1 = new JButton("Delete");
	     b1.setFont(new Font("Tahoma", Font.BOLD, 15));
	     b1.setBackground(Color.WHITE);
		 b1.setBounds(226,337,120,35);b1.setToolTipText("click to delete supplier details");
		 jf.getContentPane().add(b1);b1.addActionListener(this);

		 b2 = new JButton("Reset");
		 b2.setFont(new Font("Tahoma", Font.BOLD, 15));
		 b2.setBackground(Color.WHITE);
		 b2.setBounds(421,337,100,35);b2.setToolTipText("click to clear all textfields");
		 jf.getContentPane().add(b2); b2.addActionListener(this);

     	b3 = new JButton("Back");
     	b3.setFont(new Font("Tahoma", Font.BOLD, 15));
     	b3.setBackground(Color.WHITE);
		b3.setBounds(578,337,100,35);b3.setToolTipText("click to go to main menu");
		jf.getContentPane().add(b3); b3.addActionListener(this);

     

	     jf.setTitle("Delete Supplier");
	     jf.setSize(900,700);
		 jf.setLocation(20,20);
		 jf.setResizable(false);
		 jf.getContentPane().setBackground(Color.cyan);
		 
		 lblNewLabel = new JLabel("New label");
		 lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/Suppliers.jpg"));
		 lblNewLabel.setBounds(0, 0, 886, 673);
		 jf.getContentPane().add(lblNewLabel);
	     jf.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
      {
	   	if(((t1.getText()).equals(""))&&((t2.getText()).equals("")))
	     {
		  JOptionPane.showMessageDialog(this,"Please enter supplier id or name !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	      }
	      else
	      {//fetch
	      try
	       {
	         int foundrec = 0;
	    Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store","root","rootpasswordgiven");
		System.out.println("Connected to database.");
         ps=con.prepareStatement("select * from supplier where sid='"+t1.getText()+"' or sname='"+t2.getText()+"'");
	      rs=ps.executeQuery();
		  while(rs.next())
	      {
		    t1.setText(rs.getString(1));
	        t2.setText(rs.getString(2));
	        t3.setText(rs.getString(3));
	        t4.setText(rs.getString(4));
		    t5.setText(rs.getString(5));
		     foundrec = 1;
	       }
	       if (foundrec == 0)
                {
                    JOptionPane.showMessageDialog(null,"Record is not available","Dialog",JOptionPane.WARNING_MESSAGE);
                }
                con.close();
	      }
        catch(SQLException se)
		{
		System.out.println(se);
	     JOptionPane.showMessageDialog(null,"SQL Error:"+se);
        }
	    catch(Exception e)
	     {
	     System.out.println(e);
		 JOptionPane.showMessageDialog(null,"Error:"+e);
	     }
      }
    }

   else if(ae.getSource()==b1)
	 {//delete
	 	if(((t1.getText()).equals(""))&&((t2.getText()).equals("")))
	     {
		  JOptionPane.showMessageDialog(this,"Please enter supplier id or name !","Warning!!!",JOptionPane.ERROR_MESSAGE);
	      }
	      else
	      {
	      try
	       {
	    Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store","root","rootpasswordgiven");
		System.out.println("Connected to database.");
	    ps=con.prepareStatement("delete from supplier where sid='"+t1.getText()+"' or sname='"+t2.getText()+"'");
	    ps.executeUpdate();
	    int reply=JOptionPane.showConfirmDialog(null,"Record is deleted successfully.Do you want delete more?",null,JOptionPane.YES_NO_OPTION);

        if (reply == JOptionPane.YES_OPTION)
			{
		       jf.setVisible(false);
		       new AddNewMedicine();
		    }
		  else if (reply == JOptionPane.NO_OPTION)
			{
			  jf.setVisible(false);
			  new MainMenu();
       }
        t1.setText("");
        t2.setText("");
        t3.setText("");
        t4.setText("");
        t5.setText("");
         con.close();
	    }
        catch(SQLException se)
		{
		System.out.println(se);
	     JOptionPane.showMessageDialog(null,"SQL Error:"+se);
        }
	    catch(Exception e)
	     {
	     System.out.println(e);
		 JOptionPane.showMessageDialog(null,"Error:"+e);
	     }
	      
	      
      }
   }
     else if(ae.getSource()==b2)
      {
          t1.setText("");
          t2.setText("");
          t3.setText("");
          t4.setText("");
          t5.setText("");

      }
  else if(ae.getSource()==b3)
  {
	  new MainMenu();
	  jf.setVisible(false);
   }
 }

	public static void main(String args[])
	{
	      new DeleteSupplier();
	}
}
