package medi;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MainMenu extends JFrame implements ActionListener
{   JFrame jf;
	JMenuBar mbar;
	JMenu m1,m2,m3;
	JMenuItem m1_1,m1_2,m1_3,m1_4,m1_5,m2_1,m2_2,m2_3,m2_4,m2_5,m3_1,m3_2;
	JLabel l1,LogoColl;
	JLabel lblNewLabel;
	 JButton btnExit;

	public MainMenu()
	{
        jf=new JFrame();
		jf.getContentPane().setLayout(null);

		l1=new JLabel("WELCOME TO MEDICAL  STOCK MANAGEMENT SYSTEM");
		l1.setForeground(Color.BLACK);
		l1.setBounds(61, 429, 793, 51);
		l1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		jf.getContentPane().add(l1);

		mbar = new JMenuBar();
		jf.setJMenuBar(mbar);

		m1=new JMenu("Supplier");
		mbar.add(m1);
		m1_1 = new JMenuItem("Add New Supplier");
		m1.add(m1_1);
		m1_2 = new JMenuItem("Search Supplier");
		m1.add(m1_2);
		m1_3 = new JMenuItem("Update Supplier");
		m1.add(m1_3);
		m1_4 = new JMenuItem("Delete Supplier");
		m1.add(m1_4);
	    m1_5 = new JMenuItem("List of Suppliers");
		m1.add(m1_5);

		m2=new JMenu("Medicine");
		mbar.add(m2);
		m2_1 = new JMenuItem("Add New Medicine");
		m2.add(m2_1);
		m2_2 = new JMenuItem("Search Medicine");
		m2.add(m2_2);
		m2_3 = new JMenuItem("Update Medicine");
		m2.add(m2_3);
		m2_4 = new JMenuItem("Delete Medicine");
		m2.add(m2_4);
	    m2_5 = new JMenuItem("Stock of Medicine");
		m2.add(m2_5);


		m3=new JMenu("Report");
	    mbar.add(m3);
		m3_1 = new JMenuItem("Daily Purchase Report");
		m3.add(m3_1);

		m3_2 = new JMenuItem("Supplier wise medicine Report");
		m3.add(m3_2);

        m1_1.addActionListener(this);
		m1_2.addActionListener(this);
		m1_3.addActionListener(this);
		m1_4.addActionListener(this);
    	m1_5.addActionListener(this);

		m2_1.addActionListener(this);
		m2_2.addActionListener(this);
		m2_3.addActionListener(this);
		m2_4.addActionListener(this);
	    m2_5.addActionListener(this);

		m3_1.addActionListener(this);
		m3_2.addActionListener(this);
		

		jf.setTitle("Main Menu");
		jf.setLocation(20,20);
	    jf.setSize(900,700);
	    jf.setResizable(false);
		jf.getContentPane().setBackground(Color.orange);
		
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/MainMenu.jpg"));
		lblNewLabel.setBounds(-10, 0, 896, 644);
		jf.getContentPane().add(lblNewLabel);
		
		btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnExit.setForeground(Color.BLACK);
		btnExit.setBackground(Color.WHITE);
		btnExit.setBounds(392, 548, 123, 37);
		jf.getContentPane().add(btnExit);
		jf.setVisible(true);
		btnExit.addActionListener(this);

	}

	public void actionPerformed(ActionEvent ae)
	{

	  if(ae.getSource()==m1_1)
		{
		    new AddNewSupplier();
		    jf.setVisible(false);
		}
		else if(ae.getSource()==m1_2)
		{
		   new SearchSupplier();
		   jf.setVisible(false);
		}
		else if(ae.getSource()==m1_3)
		{
		  new UpdateSupplier();
		  jf.setVisible(false);
		}
		else if(ae.getSource()==m1_4)
		{
		  new DeleteSupplier();
		  jf.setVisible(false);
		}
	    else if(ae.getSource()==m1_5)
		{
		  new SupplierList();
		  jf.setVisible(false);
		}


		else if(ae.getSource()==m2_1)
		{
			new AddNewMedicine();
			jf.setVisible(false);
		}
		else if(ae.getSource()==m2_2)
		{
			new SearchMedicine();
			jf.setVisible(false);
		}
		else if(ae.getSource()==m2_3)
		{
			new UpdateMedicine();
			jf.setVisible(false);
		}
		else if(ae.getSource()==m2_4)
		{
			new DeleteMedicine();
			jf.setVisible(false);
		}
		else if(ae.getSource()==m2_5)
		{
			new MedicineList();
			jf.setVisible(false);
		}

		 else if(ae.getSource()==m3_1)
		 {
		   new DailyPurchaseReport();
		   jf.setVisible(false);
		 }

		  else if(ae.getSource()==m3_2)
		 {
		   new SupplierWiseMedList();
		   jf.setVisible(false);
		 }

		

		else if(ae.getSource()==btnExit)
		{
		  System.exit(0);
		}

  }

	public static void main(String args[])
	{
		new MainMenu();
	}
}
