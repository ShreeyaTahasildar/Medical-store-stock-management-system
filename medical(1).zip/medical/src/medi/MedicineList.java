package medi;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class MedicineList extends JFrame implements ActionListener
 {
    JFrame jf=new JFrame();
    JLabel ln;
    Connection con;
    PreparedStatement ps;
    Statement stmt;
    ResultSet rs;
 	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);
    JLabel lblNewLabel = new JLabel("New label");
    JButton btnBack,btnPrint;
   

  public MedicineList()
  {
    jf.getContentPane().setLayout(null);
  	ln = new JLabel("Stock Of Medicines");
    ln.setFont(new Font("Times New Roman", Font.BOLD, 25));
    ln.setForeground(Color.BLACK);
    ln.setBounds(300,30,300,25);
    jf.getContentPane().add(ln);

    scrlPane.setBounds(0,80,900,600);
    jf.getContentPane().add(scrlPane);
    tabGrid.setFont(new Font ("Times New Roman",0,15));

    model.addColumn("Batchno");model.addColumn("Name");model.addColumn("Quantity");
  	model.addColumn("Type");model.addColumn("Purcahasedate");model.addColumn("Expirydate");model.addColumn("Purchaseprice");
    model.addColumn("Supplierid");model.addColumn("Suppliername");
  		int r = 0;
     try
     {

     	Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store","root","rootpasswordgiven");
		System.out.println("Connected to database.");
		stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        rs = stmt.executeQuery("select * from medicine");
          while(rs.next())
            {
            	model.insertRow(r++,new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)});

            }

             con.close();
       }
      catch(SQLException se)
       {
       	  System.out.println(se);
          JOptionPane.showMessageDialog(null,"SQL Error:"+se);
       }
       catch(Exception e)
       {
       	   System.out.println(e);
           JOptionPane.showMessageDialog(null,"Error:"+e);
       }


    jf.setTitle("Medicine List");
    jf.setSize(900,700);
	jf.setLocation(20,20);
	jf.setResizable(false);
    jf.getContentPane().setBackground(Color.cyan);
    lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/DeleteMedicine.jpg"));
    lblNewLabel.setBounds(0, 0, 886, 83);
    jf.getContentPane().add(lblNewLabel);
    
    
    btnPrint = new JButton("Print");
    btnPrint.setFont(new Font("Tahoma", Font.BOLD, 15));
    btnPrint.setBounds(764, 37, 85, 21);
    btnPrint.addActionListener(this);
    jf.getContentPane().add(btnPrint);
    
    btnBack = new JButton("Back");
    btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
    btnBack.setBounds(10, 37, 85, 21);
    btnBack.addActionListener(this);
    jf.getContentPane().add(btnBack);
    
   
    
    jf.setVisible(true);
  }


  public static void main(String args[])
    {
    	new MedicineList();
    }



public void actionPerformed(ActionEvent a1) {
	
	
	
	if(a1.getSource()==btnBack)
	 {
		new MainMenu();
		jf.setVisible(false);
		
		
	}

	 else if(a1.getSource()==btnPrint)
	 {
		 jf.setVisible(false);
	 }
	
}
}
