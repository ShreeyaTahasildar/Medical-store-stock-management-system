package medi;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class InvalidException extends Exception
{
}

class Login extends JFrame implements ActionListener
{
	JFrame jf;
	JButton b1,b2,b3;
	JLabel l1,l2,l3;
	JTextField t1,t2;
	JPasswordField p1;
	Font f;
	int cnt=0,cnt1=0;
	private JButton b4;
	

	Login()
	{
		
		
        jf=new JFrame();
        f = new Font("Times New Roman",Font.BOLD,20);
		jf.getContentPane().setLayout(null);
		

        l3 = new JLabel("ADMINISTRATOR");
        l3.setForeground(Color.BLACK);l3.setFont(new Font("Times New Roman", Font.BOLD, 35));
        l3.setBounds(210,84,345,80);
		jf.getContentPane().add(l3);

		l3 = new JLabel();
		l3.setBounds(150,250,50,25);
		jf.getContentPane().add(l3);

		l1 = new JLabel("User Name : "); 
		l1.setForeground(Color.BLACK);l1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		l1.setBounds(210,250,210,25);
		jf.getContentPane().add(l1);

		t1 = new JTextField(20);
		t1.setBounds(350,250,200,25);
		t1.setToolTipText("Enter Username");
		jf.getContentPane().add(t1);

        

		l2 = new JLabel("Password  : "); 
		l2.setForeground(Color.BLACK);l2.setFont(new Font("Times New Roman", Font.BOLD, 25));
		l2.setBounds(210,297,210,28);
		jf.getContentPane().add(l2);

		p1 = new JPasswordField(20);
		p1.setBounds(350,300,200,25);
		p1.setToolTipText("Enter Password");
		jf.getContentPane().add(p1);

		b1 = new JButton("Login");
		b1.setFont(new Font("Tahoma", Font.BOLD, 15));
		b1.setBackground(Color.WHITE);
		b1.setForeground(Color.BLACK);
		b1.setBounds(200,400,100,35);
		jf.getContentPane().add(b1);b1.addActionListener(this);

		b2 = new JButton("Reset");
		b2.setFont(new Font("Tahoma", Font.BOLD, 15));
		b2.setBackground(Color.WHITE);
		b2.setForeground(Color.BLACK);
		b2.setBounds(320,400,100,35);
		jf.getContentPane().add(b2);b2.addActionListener(this);

		b3 = new JButton("Exit");
		b3.setFont(new Font("Tahoma", Font.BOLD, 15));
		b3.setBackground(Color.WHITE);
		b3.setForeground(Color.BLACK);
		b3.setBounds(440,400,100,35);
		jf.getContentPane().add(b3);
		
		b4 = new JButton("Forgot password?");
		b4.setFont(new Font("Tahoma", Font.BOLD, 15));
		b4.setForeground(Color.BLACK);
		b4.setBackground(Color.WHITE);
		b4.setBounds(255, 465, 260, 25);
		jf.getContentPane().add(b4);b4.addActionListener(this);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/ubuntu/Desktop/login.jpg"));
		lblNewLabel.setBounds(0, -16, 786, 590);
		jf.getContentPane().add(lblNewLabel);
		
		

		jf.setTitle("Login");
		jf.setLocation(20,20);
		jf.setSize(800,600);
		jf.setResizable(false);
		jf.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			try
			{
				String s=t1.getText();
				String s1=new String(p1.getPassword());
				if((s.compareTo("admin")==0)&&(s1.compareTo("admin123")==0))
				{
					JOptionPane.showMessageDialog(null," Welcome !!! You are valid user ...!!!  ","WELCOME",JOptionPane.INFORMATION_MESSAGE);
			   	    jf.setVisible(false);
                       new MainMenu();
				}
				else
				{
					throw new InvalidException();
				}
			}
			catch(Exception e1)
			{
			    cnt++;
			    JOptionPane.showMessageDialog(null," Sorry !!! You are not valid user ...!!!","WARNING",JOptionPane.ERROR_MESSAGE);
			    t1.setText("");
			    p1.setText("");
			    if(cnt==3)
			    {
			         JOptionPane.showMessageDialog(null,"Sorry !!! Your 3 attempts are over ...!!!","WARNING",JOptionPane.ERROR_MESSAGE);
			         System.exit(0);
			    }
            }

		}

		else if(ae.getSource()==b2)
		{
			t1.setText("");
			p1.setText("");

		}

		else if(ae.getSource()==b3)
		{
		    System.exit(0);
		}
		
		else if(ae.getSource()==b4)
		{
			new Forgot();
			jf.setVisible(false);
		}
	}

	public static void main(String args[])
	{
		new Login();

	}

}
